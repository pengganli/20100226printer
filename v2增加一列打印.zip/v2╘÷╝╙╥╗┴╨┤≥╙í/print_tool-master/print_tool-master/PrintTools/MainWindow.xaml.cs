﻿using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Threading;
using System.Diagnostics;
using System.IO;
using System.Data;
using System.Text;
using Microsoft.Win32;

namespace PrintTools
{
    /// <summary>
    /// 打印主页面的实现，打印主页面和打印出来的纸页面的布局各走各的布局
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// 使用委托传递方法当做参数进行调用打印的方法
        /// </summary>
        private delegate void DoPrintMethod(PrintDialog printDialog, DocumentPaginator documentPaginator);

        /// <summary>
        /// 定义委托执行将打印完成的控件重新置为可用
        /// </summary>
        private delegate void EnableButtonMethod();
        

        private DataTable dt;
        private FileStream fsNotFoundLog;
        private StreamWriter swNotFoundLog;
        private FileStream fsPDFNotFoundLog;
        private StreamWriter swPDFNotFoundLog;
        private FileStream fsFnSku = null;
        private StreamWriter swFnSku = null;

        private DateTime _time;
        private bool waitForScan;
        private System.Timers.Timer t;

        /// <summary>
        /// 初始化页面首次调用的方法
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            ProcessActivate();
            _time = DateTime.Now;
            waitForScan = true;
         //   t = new System.Timers.Timer(200);//实例化Timer类，设置间隔时间为10000毫秒；
          //  t.Elapsed += new System.Timers.ElapsedEventHandler(theout);//到达时间的时候执行事件；
         //   t.AutoReset = true;//设置是执行一次（false）还是一直执行(true)；
			Topmost = true; 

            dt = new DataTable();
            bool bFirst = true;
            string csvFolder = ".\\csv\\";
            string [] files = Directory.GetFiles(csvFolder, "*.csv", System.IO.SearchOption.TopDirectoryOnly);
            if (files.Count() == 0)
            {
                MessageBox.Show(" CSV file not found. This application will exit.", "Alert");
                Environment.Exit(0);
            }
            foreach (string file in files)
            {
                OpenCSV(file, dt, bFirst);
                bFirst = false;
            }
            OpenNotFoundLog();

            skubox.Focus();
        }

        // 判断注册表项是否存在
        private bool IsRegeditItemExist(string subkey)
        {
            bool ret = false;
            RegistryKey hkml = Registry.LocalMachine;
            RegistryKey software = hkml.OpenSubKey(subkey);
            if(software != null)
            {
                software.Close();
                ret = true;
            }
            else
            {
                hkml.Close();
            }
            
            return ret;
        }

        private bool IsRegeditKeyExist(string subkey, string keyname)
        {
            string[] valueNames;

            RegistryKey hkml = Registry.LocalMachine;
            RegistryKey software = hkml.OpenSubKey(subkey);
            if (software == null)
            {
                hkml.Close();
                return false;
            }
            valueNames = software.GetValueNames();
            foreach (string keyName in valueNames)
            {
                if (keyName == keyname)  //判断键值的名称
                {
                    software.Close();
                    return true;
                }
            }
            software.Close();

            return false;
        }

        private string GetRegeditKeyValue(string subkey, string keyname)
        {
            string info = "";
            RegistryKey hkml = Registry.LocalMachine;
            RegistryKey software = hkml.OpenSubKey(subkey);
            if (software == null)
            {
                hkml.Close();
                return info;
            }
            info = software.GetValue(keyname).ToString();
            software.Close();

            return info;
        }

        private bool IsLicenseExpired(int expireDay)
        {
            bool ret = IsRegeditKeyExist("SOFTWARE\\Printools", "activate_date");
            if (!ret) return true;

            ret = false;
            DateTime runtime = DateTime.Now.Date;
            string activateDate = GetRegeditKeyValue("SOFTWARE\\Printools", "activate_date");
            try
            {
                DateTime activate = DateTime.Parse(activateDate);
                DateTime expireDate = activate.AddDays(expireDay);
                int comp = runtime.CompareTo(expireDate);
                int comp2 = activate.CompareTo(runtime);
                if (comp > 0 || comp2 > 0)
                {
                    ret = true;
                }
            }
            catch(FormatException)
            {
                ret = true;
            }
            
            return ret;
        }

        private bool NeedActivate()
        {
            bool ret = IsLicenseExpired(15);

            return ret;
        }

        private void ProcessActivate()
        {
         //   bool ret = NeedActivate();
            bool ret = false;
            if (!ret)
            {
                passwordBox.Visibility = Visibility.Hidden;
                label2.Visibility = Visibility.Hidden;
                label3.Visibility = Visibility.Hidden;
                button1.Visibility = Visibility.Hidden;
                button.Visibility = Visibility.Visible;
            }
            else
            {
                passwordBox.Focus();
            }
        }


        private bool OpenNotFoundLog()
        {
            Encoding encoding = Encoding.ASCII;//
            try
            {
                fsNotFoundLog = new FileStream(".\\log\\NotFound.txt", System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write);

                //StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                swNotFoundLog = new StreamWriter(fsNotFoundLog, encoding);
                swNotFoundLog.AutoFlush = true;
                fsNotFoundLog.Position = fsNotFoundLog.Length;

                fsPDFNotFoundLog = new FileStream(".\\log\\PDF_NotFound.txt", System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write);

                swPDFNotFoundLog = new StreamWriter(fsPDFNotFoundLog, encoding);
                swPDFNotFoundLog.AutoFlush = true;
                fsPDFNotFoundLog.Position = fsPDFNotFoundLog.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("The application will exit.");
                Environment.Exit(0);
            }
            return true;
        }

            /// <summary>
            /// 将CSV文件的数据读取到DataTable中
            /// </summary>
            /// <param name="fileName">CSV文件路径</param>
            /// <returns>返回读取了CSV数据的DataTable</returns>
            public static bool OpenCSV(string filePath, DataTable dt, bool isFirst)
            {
                Encoding encoding = Encoding.ASCII;//
                try
                {
                    FileStream fs = new FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read);

                    //StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                    StreamReader sr = new StreamReader(fs, encoding);
                    //string fileContent = sr.ReadToEnd();
                    //encoding = sr.CurrentEncoding;
                    //记录每次读取的一行记录
                    string strLine = "";
                    //记录每行记录中的各字段内容
                    string[] aryLine = null;
                    string[] tableHead = null;
                    //标示列数
                    int columnCount = 0;
                    //标示是否是读取的第一行
                    bool IsFirst = isFirst;
                    //逐行读取CSV中的数据
                    while ((strLine = sr.ReadLine()) != null)
                    {
                        //strLine = Common.ConvertStringUTF8(strLine, encoding);
                        //strLine = Common.ConvertStringUTF8(strLine);

                        if (IsFirst == true)
                        {
                            tableHead = strLine.Split(',');
                            IsFirst = false;
                            columnCount = tableHead.Length;
                            //创建列
                            for (int i = 0; i < columnCount; i++)
                            {
                                DataColumn dc = new DataColumn(tableHead[i]);
                                dt.Columns.Add(dc);
                            }
                        }
                        else
                        {
                            aryLine = strLine.Split(',');
                            DataRow dr = dt.NewRow();
                            for (int j = 0; j < columnCount; j++)
                            {
                                dr[j] = aryLine[j];
                            }
                            dt.Rows.Add(dr);
                        }
                    }
                    if (aryLine != null && aryLine.Length > 0)
                    {
                        dt.DefaultView.Sort = tableHead[0] + " " + "asc";
                    }

                    sr.Close();
                    fs.Close();
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("The application will exit.");
                Environment.Exit(0);
            }
                
                return true;
            }

        public void theout(object source, System.Timers.ElapsedEventArgs e)
        {
            DateTime curTime = DateTime.Now;
            TimeSpan ts = curTime.Subtract(_time);
            if (ts.Milliseconds > 200)    // 
            {
                //MessageBox.Show("print code!");
                this.Dispatcher.Invoke(
                    new Action(
                        delegate
                        {
                  //          printCode();
                        }
                    )
                );
            }
        }

        private void Skubox_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            //MessageBox.Show("Key down" + e.Key);
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                printCode();
                return;
            }
        //    else
         //   {
         //       if (waitForScan)
         //       {
         //           waitForScan = false;
          //          t.Start();
          //      }
          //      DateTime curTime = DateTime.Now;
          //      _time = curTime;
          //  }
        }

        private void printNotFoundLog(string scan_code)
        {
            swNotFoundLog.WriteLine(scan_code);
        }

        private void printPDFNotFoundLog(string fnsku)
        {
            swPDFNotFoundLog.WriteLine(fnsku);
        }

        private void printFnSkuLog(string fnsku)
        {
            swFnSku.WriteLine(fnsku);
        }

        private void printCode()
        {
    //        if (!waitForScan)
    //        {
    //            waitForScan = true;
    //            t.Stop();
     //       }
            
            try
            {
                skubox.Focus();
                string sku = skubox.Text;
                if (sku.Length == 0)
                {
                    return;
                }
                skubox.Clear();
                
                string searchFilter = "[SCAN] = '" + sku + "'";
                DataRow[] rows = dt.Select(searchFilter);

                string fnsku;
                if (rows.Count() != 0)
                {
                    DataRow row = rows[0];
                    fnsku = row["FNSKU"].ToString();
                }
                else
                {
                    MessageBox.Show("Scan code is not in database.");
                    printNotFoundLog(sku);
                    Console.Beep(500, 2000);
                    return;
                }

                string pathStr = ".\\pdf\\" + fnsku + ".pdf";

                if (File.Exists(pathStr) == false)
                {
                    MessageBox.Show(fnsku + ".pdf does not exist.");
                    printPDFNotFoundLog(fnsku);
                    Console.Beep(300, 1000);
                    return;
                }

                printFnSkuLog(fnsku);
				//var printerSettings = new PrinterSettings();

				// 增加一列打印 linya
				string qr;
				if (rows.Count() != 0)
				{
					DataRow row = rows[0];
					qr = row["QR"].ToString();
				}
				else
				{
					MessageBox.Show("Scan code is not in database.");
					printNotFoundLog(sku);
                    Console.Beep(500, 2000);
                    return;
				}

				string pathStr3 = ".\\pdf\\" + qr + ".pdf";

				if (File.Exists(pathStr3) == false)
				{
					MessageBox.Show(qr + ".pdf does not exist.");
					printPDFNotFoundLog(qr);
                    Console.Beep(300, 1000);
                    return;
				}

	//			printFnSkuLog(qr);

				var pr = new Process
                {
                    StartInfo =
                        {
                            FileName = pathStr,
                            CreateNoWindow = true,
                            WindowStyle = ProcessWindowStyle.Hidden,
                            Verb = "Printto"
                        }
                };
                pr.Start();
                if (!pr.WaitForExit(7000))
                {
                    // kill Adobe Reader
                    pr.Kill();
                }
                //MessageBox.Show(pathStr);

                var pr3  = new Process
                {
                    StartInfo =
                        {
                            FileName = pathStr3,
                            CreateNoWindow = true,
                            WindowStyle = ProcessWindowStyle.Hidden,
                            Verb = "Printto"
                        }
                };
                pr3.Start();
                if (!pr3.WaitForExit(10000))
                {
                    // kill Adobe Reader
                    pr3.Kill();
                }
                skubox.Focus();
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("The application will exit.");
                Environment.Exit(0);
            }
            return;
        }

        private bool OpenFNSkuLog(string filename)
        {
            Encoding encoding = Encoding.ASCII;//
            try
            {
                if (fsFnSku != null)
                {
                    swFnSku.Close();
                    swFnSku = null;
                    fsFnSku.Close();
                    fsFnSku = null;
                }
                
                fsFnSku = new FileStream(filename, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write);
              
                //StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                swFnSku = new StreamWriter(fsFnSku, encoding);
                swFnSku.AutoFlush = true;
                fsFnSku.Position = fsFnSku.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("The application will exit.");
                Environment.Exit(0);
            }
            return true;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory() + "\\log\\";
            openFileDialog1.CheckFileExists = false;
            openFileDialog1.Filter = "(*.csv)|*.csv";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            { //此处做你想做的事
                //this.txt_datasource.Text = openFileDialog1.FileName;
                OpenFNSkuLog(openFileDialog1.FileName);
                //MessageBox.Show(openFileDialog1.FileName);
                skubox.Visibility = Visibility.Visible;
                label.Visibility = Visibility.Visible;
                textblock.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show(" Select a log file first. ");
            }
            
        }

        // TODO: 激活界面功能：
        // 1. 输入激活码，如不正确，则提示，三次后提示并关闭程序
        // 2. 如果输入正确，则初始化注册表，生成注册项目，键值赋值为当前日期。 进入正常界面，激活界面消失

        private bool InitRegistryItem()
        {
            RegistryKey key = Registry.LocalMachine;
            RegistryKey software = key.CreateSubKey("SOFTWARE\\Printools");
            DateTime now = DateTime.Now.Date;
            software.SetValue("activate_date", now.ToShortDateString());
            software.Close();

            bool ret = IsLicenseExpired(1);
            if (ret) return false;

            return true;
        }


        private bool CheckActivationCode(string code)
        {
            string ac = "06242209";
            return code.Equals(ac);
        }

        private void Activate_Software(object sender, RoutedEventArgs e)
        {
            string activate_code = passwordBox.Password;
            bool passCheck = CheckActivationCode(activate_code);
            if(passCheck)
            {
                bool ret = InitRegistryItem();
                if(!ret)
                {
                    MessageBox.Show(" Activation failed and the program will exit");
                    Environment.Exit(0);
                }
                passwordBox.Visibility = Visibility.Hidden;
                label2.Visibility = Visibility.Hidden;
                label3.Visibility = Visibility.Hidden;
                button1.Visibility = Visibility.Hidden;
                button.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show(" Activation code invalid: " + activate_code + ", Bye ");
                Environment.Exit(0);
            }

            passwordBox.Clear();
        }
    }
}